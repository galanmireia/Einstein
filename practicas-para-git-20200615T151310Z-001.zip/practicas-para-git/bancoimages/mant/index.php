<?session_start();?>
<?include("../../lanb_ado.php");
include("../../lanb_clase.php");
include("../../edicionImagenes/ImageEditor.php");
include("../../lanb_rutas.php");
include("../../multi/lanb_idiomas.php");
include("../../lanb_estructura.php");
include("../../lanb_edukia.php");
include("../lanb_estruktura.php");
include("../lanb_edukia.php");
include("../lanb_sql.php");
?>
<HTML>
<HEAD>
<title>..:: Einstein ::.. Irudiak / Im�genes / Photos</title>
<script language="javascript" src="../../js/capas.js"></script>
<script language="javascript" src="../../js/fecha.js"></script>
<script language="javascript" src="../../js/egunabalidatu.js"></script>
<script language="javascript" src="../../js/cargar.js"></script>
<script language="javascript" src="../../js/validar.js"></script>
<script language="javascript" src="../../js/validarfecha.js"></script>
<script language="javascript" src="../js/balidatu.js"></script>
<LINK rel="stylesheet" type="text/css" href="../../estilos.css">
</HEAD>
<BODY leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" BORDER=0 NORESIZE  frameborder="NO">
<table align="center" width="100%" height="100%"  CELLPADDING=0 CELLSPACING=0 topmargin=0 leftmargin=0 border=0>
<tr><td valign="middle">
<table width="100%" height="100%"  CELLPADDING=0 CELLSPACING=0 topmargin=0 leftmargin=0 border=0>
<tr><td width=100% height="100%" align="left" valign="top"><?sEdukia();?></td></tr>
</table>
</td></tR>
</table>
</BODY>
</HTML>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<frameset rows="80,*">
<frame src="arriba.php" name="top" scrolling="no" />
<frame src="abajo.php" name="main" />
</ frameset>
</HTML>

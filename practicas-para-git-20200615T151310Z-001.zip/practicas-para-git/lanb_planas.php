<?function fDibujarDia5(){?>
<font class=textogn><?echo sEscribir("Lunes5deSeptiembre");?></font>
<table border=0 width=100% cellpadding=4 cellspacing=0>
<tr><td height=5></td></tr>
<tr><td class=textom><?echo sEscribir("De1600a1730Documentacion");?></td></tr>
<!--<tr><td class=textom><font class=textom2>17:30</font> <b><?echo sEscribir("Lunes5deSeptiembre_1730");?></b></td></tr>-->
<tr><td class=textom><font class=textom2>18:00</font> <?echo sEscribir("Lunes5deSeptiembre_1800");?></td></tr>
<tr><td class=textom><font class=textom2>18:30</font> <?echo sEscribir("Lunes5deSeptiembre_1830");?></td></tr>
<tr><td class=textom><font class=textom2>19:30</font> <?echo sEscribir("Lunes5deSeptiembre_1930");?></td></tr>
<tr><td class=textom><font class=textom2>21:00</font> <?echo sEscribir("Lunes5deSeptiembre_2100");?></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>
</table>
<?}
function fDibujarDia6(){?>
<font class=textogn><?echo sEscribir("Martes6deSeptiembre");?></font>
<table width=100% cellpadding=2 cellspacing=0>
<tr><td height=5></td></tr>
<tr><td class=textom><font class=textom2>9:00</font> <b><?echo sEscribir("Martes6deSeptiembre_900");?></b></td></tr>
<tr><td class=textom><font class=textom2>9:30</font> <a href="index.php?pg=7&ponente=4" target="einstein_ponente"><font class=textomna2>A. Galindo</font></a> <i><?echo sEscribir("Martes6deSeptiembre_930");?></i></td></tr>
<tr><td class=textom><font class=textom2>10:30</font> <a href="index.php?pg=7&ponente=10" target="einstein_ponente"><font class=textomna2>R. Rebolo</font></a> <i><?echo sEscribir("Martes6deSeptiembre_1130");?></i></td></tr>
<tr><td class=textom><font class=textom2>11:30</font> <b><?echo sEscribir("Martes6deSeptiembre_1100");?></b></td></tr>
<tr><td class=textom><font class=textom2>12:00</font> <a href="index.php?pg=7&ponente=19" target="einstein_ponente"><font class=textomna2>A. A. Lucas</font></a> <i><?echo sEscribir("Martes6deSeptiembre_1133");?></i></td></tr>
<tr><td class=textom><font class=textom2>13:00</font> <a href="index.php?pg=7&ponente=18" target="einstein_ponente"><font class=textomna2>F. Flores</font></a> <i><?echo sEscribir("Martes6deSeptiembre_1215");?></i></td></tr>
<tr><td class=textom><font class=textom2>14:00</font> <b><?echo sEscribir("Martes6deSeptiembre_1330");?></b></td></tr>
<tr><td height=15></td></tr>
<tr><td class=textom><font class=textom2>17:30</font> <b><?echo sEscribir("Martes6deSeptiembre_900");?></b></td></tr>
<tr><td class=textom><font class=textom2>18:00</font> <a href="index.php?pg=7&ponente=11" target="einstein_ponente"><font class=textomna2>H. Rohrer</font></a> <?echo sEscribir("Martes6deSeptiembre_1800");?></td></tr>
<tr><td class=textom><font class=textom2>19:00</font> <a href="index.php?pg=7&ponente=1" target="einstein_ponente"><font class=textomna2>J. M. Lehn</font></a> <?echo sEscribir("Martes6deSeptiembre_1845");?></td></tr>
<tr><td class=textom><font class=textom2>20:00</font> <a href="index.php?pg=7&ponente=7" target="einstein_ponente"><font class=textomna2>D. Herschbach</font></a> <?echo sEscribir("Martes6deSeptiembre_1930");?></td></tr>
<tr><td class=textom><font class=textom2>21:00</font> <?echo sEscribir("Martes6deSeptiembre_2015");?>
</table>
<?}
function fDibujarDia7(){?>
<font class=textogn><?echo sEscribir("Miercoles7deSeptiembre");?></font>
<table width=100% cellpadding=2 cellspacing=0>
<tr><td height=5></td></tr>
<tr><td class=textom><font class=textom2>9:00</font> <b><?echo sEscribir("Miercoles7deSeptiembre_900");?></b></td></tr>
<tr><td class=textom><font class=textom2>9:30</font> <a href="index.php?pg=7&ponente=16" target="einstein_ponente"><font class=textomna2>A. Zeilinger</font></a> <i><?echo sEscribir("Miercoles7deSeptiembre_930");?></i></td></tr>
<tr><td class=textom><font class=textom2>10:30</font> <a href="index.php?pg=7&ponente=2" target="einstein_ponente"><font class=textomna2>I. Cirac.</font></a> <i><?echo sEscribir("Miercoles7deSeptiembre_930");?></i></td></tr>
<tr><td class=textom><font class=textom2>11:30</font> <b><?echo sEscribir("Miercoles7deSeptiembre_1130");?></b></td></tr>
<tr><td class=textom><font class=textom2>12:00</font> <a href="index.php?pg=7&ponente=15" target="einstein_ponente"><font class=textomna2>F. J. Yndurain.</font></a> <i><?echo sEscribir("Miercoles7deSeptiembre_1015");?></i></td></tr>
<tr><td class=textom><font class=textom2>13:00</font> <b><?echo sEscribir("Miercoles7deSeptiembre_1300");?></b></td></tr>
<tr><td height=15></td></tr>
<tr><td class=textom><font class=textom2>17:30</font> <b><?echo sEscribir("Miercoles7deSeptiembre_900");?></b></td></tr>
<tr><td class=textom><font class=textom2>18:00</font> <a href="index.php?pg=7&ponente=6" target="einstein_ponente"><font class=textomna2>S. Glashow</font></a> <i><?echo sEscribir("Miercoles7deSeptiembre_1700");?></i></td></tr>
<tr><td class=textom><font class=textom2>19:00</font> <a href="index.php?pg=7&ponente=8" target="einstein_ponente"><font class=textomna2>A. Hewish</font></a> <?echo sEscribir("Miercoles7deSeptiembre_1800");?></td></tr>
<tr><td class=textom><font class=textom2>20:00</font> <a href="index.php?pg=7&ponente=3" target="einstein_ponente"><font class=textomna2>C. M. Will</font></a> <i><?echo sEscribir("Miercoles7deSeptiembre_1845");?></i></td></tr>
<tr><td class=textom><font class=textom2>21:00</font> <b><?echo sEscribir("Miercoles7deSeptiembre_2015");?></b></td></tr>
</table>
<?}
function fDibujarDia8(){?>
<font class=textogn><?echo sEscribir("Jueves8deSeptiembre");?></font>
<table width=100% cellpadding=2 cellspacing=0>
<tr><td height=5></td></tr>
<tr><td class=textom><font class=textom2>9:00</font> <b><?echo sEscribir("Jueves8deSeptiembre_900");?></b></td></tr>
<tr><td class=textom><font class=textom2>9:30</font> <a href="index.php?pg=7&ponente=17" target="einstein_ponente"><font class=textomna2>P. Pascual.</font></a> <i><?echo sEscribir("Jueves8deSeptiembre_930");?></i></td></tr>
<tr><td class=textom><font class=textom2>10:30</font> <a href="index.php?pg=7&ponente=3" target="einstein_ponente"><font class=textomna2>C. M. Will.</font></a> <i><?echo sEscribir("Jueves8deSeptiembre_1015");?></i></td></tr>
<tr><td class=textom><font class=textom2>11:30</font> <b><?echo sEscribir("Jueves8deSeptiembre_1100");?></b></td></tr>
<tr><td class=textom><font class=textom2>12:00</font> <a href="index.php?pg=7&ponente=12" target="einstein_ponente"><font class=textomna2>J.M. Sanchez Ron.</font></a> <i><?echo sEscribir("Jueves8deSeptiembre_1130");?></i></td></tr>
<tr><td class=textom><font class=textom2>13:00</font> <b><?echo sEscribir("Jueves8deSeptiembre_1300");?></b></td></tr>
<tr><td height=15></td></tr>
<tr><td class=textom><font class=textom2>17:30</font> <b><?echo sEscribir("Jueves8deSeptiembre_900");?></b></td></tr>
<tr><td class=textom><font class=textom2>18:00</font> <a href="index.php?pg=7&ponente=5" target="einstein_ponente"><font class=textomna2>G. Holton</font></a>	<i><?echo sEscribir("Jueves8deSeptiembre_1800");?></i></td></tr>
<tr><td class=textom><font class=textom2>19:00</font> <a href="index.php?pg=7&ponente=9" target="einstein_ponente"><font class=textomna2>A. I. Miller</font></a> <i><?echo sEscribir("Jueves8deSeptiembre_1845");?></i></td></tr>
<tr><td class=textom><font class=textom2>20:00</font> <a href="index.php?pg=7&ponente=13" target="einstein_ponente"><font class=textomna2>J. Stachel</font></a>	<i><?echo sEscribir("Jueves8deSeptiembre_1930");?></i></td></tr>
<tr><td class=textom><font class=textom2>21:00</font> <b><?echo sEscribir("Jueves8deSeptiembre_2015");?></b></td></tr>
<!--<tr><td class=textom><font class=textom2>21:00</font> <b><?echo sEscribir("Jueves8deSeptiembre_2100");?></b></td></tr>-->
</table>
<?}
function fDibujarIntroduccion(){echo sEscribir("InfoGeneral_Introduccion");}
function fDibujarVidaYObra (){echo sEscribir("AlbertEinstein_VidaYObra");}
function fDibujarPonentes (){?>
<b><?echo sEscribir("Ponentes");?></b>
<br>
<br> <a href="index.php?pg=4&opcion=18&ponente=2"><b>IGNACIO CIRAC</b></a>
<br><?echo sEscribir("Ponente1");?>
<br><br> <a href="index.php?pg=4&opcion=26&ponente=14"><b>CLAUDE COHEN-TANNOUDJI</b></a>
<br><?echo sEscribir("Ponente2");?>
<br><br> <a href="index.php?pg=4&opcion=1&ponente=18"><b>FERNANDO FLORES</b></a>
<br><?echo sEscribir("Ponente3");?>
<br><br> <a href="index.php?pg=4&opcion=1&ponente=4"><b>ALBERTO GALINDO</b></a>
<br><?echo sEscribir("Ponente4");?>
<br><br> <a href="index.php?pg=4&opcion=18&ponente=6"><b>SHELDON GLASHOW </b></a>
<br><?echo sEscribir("Ponente5");?>
<br><br> <a href="index.php?pg=4&opcion=1&ponente=7"><b>DUDLEY HERSCHBACH</b></a>
<br><?echo sEscribir("Ponente6");?>
<br><br> <a href="index.php?pg=4&opcion=18&ponente=8"><b>ANTONY HEWISH</b></a>
<br><?echo sEscribir("Ponente7");?>
<br><br> <a href="index.php?pg=4&opcion=19&ponente=5"><b>GERALD HOLTON</b></a>
<br><?echo sEscribir("Ponente8");?>
<br><br> <a href="index.php?pg=4&opcion=1&ponente=1"><b>JEAN-MARIE LEHN</b></a>
<br><?echo sEscribir("Ponente9");?>
<br><br> <a href="index.php?pg=4&opcion=19&ponente=9"><b>ARTHUR I. MILLER</b></a>
<br><?echo sEscribir("Ponente10");?>
<br><br> <a href="index.php?pg=4&opcion=19&ponente=17"><b>PEDRO PASCUAL</b></a>
<br><?echo sEscribir("Ponente11");?>
<br><br> <a href="index.php?pg=4&opcion=1&ponente=10"><b>RAFAEL REBOLO LOPEZ</b></a>
<br><?echo sEscribir("Ponente12");?>
<br><br> <a href="index.php?pg=4&opcion=1&ponente=11"><b>HEINRICH ROHRER</b></a>
<br><?echo sEscribir("Ponente13");?>
<br><br> <a href="index.php?pg=4&opcion=19&ponente=12"><b>JOSE M. SANCHEZ-RON</b></a>
<br><?echo sEscribir("Ponente14");?>
<br><br> <a href="index.php?pg=4&opcion=19&ponente=13"><b>JOHN JAY STACHEL</b></a>
<br><?echo sEscribir("Ponente15");?>
<br><br> <a href="index.php?pg=4&opcion=18&ponente=3"><b>CLIFFORD M. WILL</b></a>
<br><?echo sEscribir("Ponente16");?>
<br><br> <a href="index.php?pg=4&opcion=18&ponente=15"><b>FRANCISCO JOS� YNDURAIN</b></a>
<br><?echo sEscribir("Ponente17");?>
<br><br> <a href="index.php?pg=4&opcion=18&ponente=16"><b>ANTON ZEILINGER</b></a>
<br><?echo sEscribir("Ponente18");?>
<br><br> <a href="index.php?pg=4&opcion=18&ponente=19"><b>AMAND LUCAS</b></a>
<br><?echo sEscribir("Ponente19");?>
<?}
function fDibujarPatrocinadores (){echo sEscribir("Menu_Patrocinadores");}
function fDibujar5Trabajos (){echo sEscribir("AlbertEinstein_5Trabajos");}
function fDibujarCulminacion (){echo sEscribir("AlbertEinstein_Culminacion");}
function fDibujarImpactoDeLaObra (){echo sEscribir("AlbertEinstein_ImpactoObra");}
function fDibujarSignificadoSociedadVasca (){echo sEscribir("AlbertEinstein_Significado");}
function fDibujarMiramonKutxaEspacio (){echo sEscribir("InfoGeneral_Kutxaespacio");}
function fDibujarLaSede (){echo sEscribir("Programa_LaSede");}
function fDibujarComoLlegarSS (){echo sEscribir("InfoGeneral_ComoLlegar");}
function fDibujarAbstractLehn (){echo sEscribir("Ponente_A_Lehn");}
function fDibujarCurriculumLehn (){echo sEscribir("Ponente_C_Lehn");}
function fDibujarAbstractCirac (){echo sEscribir("Ponente_A_Cirac");}
function fDibujarCurriculumCirac (){echo sEscribir("Ponente_C_Cirac");}
function fDibujarAbstractClifford (){echo sEscribir("Ponente_A_Clifford");}
function fDibujarCurriculumClifford (){echo sEscribir("Ponente_C_Clifford");}
function fDibujarAbstractGalido (){echo sEscribir("Ponente_A_Galindo");}
function fDibujarCurriculumGalindo (){echo sEscribir("Ponente_C_Galindo");}
function fDibujarAbstractGerald (){echo sEscribir("Ponente_A_Gerald");}
function fDibujarCurriculumGerald (){echo sEscribir("Ponente_C_Gerald");}
function fDibujarAbstractSheldon (){echo sEscribir("Ponente_A_Sheldon");}
function fDibujarCurriculumSheldon (){echo sEscribir("Ponente_C_Sheldon");}
function fDibujarAbstractDudley (){echo sEscribir("Ponente_A_Dudley");}
function fDibujarCurriculumDudley (){echo sEscribir("Ponente_C_Dudley");}
function fDibujarAbstractHewish (){echo sEscribir("Ponente_A_Hewish");}
function fDibujarCurriculumHewish (){echo sEscribir("Ponente_C_Hewish");}
function fDibujarAbstractMiller (){echo sEscribir("Ponente_A_Miller");}
function fDibujarCurriculumMiller (){echo sEscribir("Ponente_C_Miller");}
function fDibujarAbstractRebolo (){echo sEscribir("Ponente_A_Rebolo");}
function fDibujarCurriculumRebolo (){echo sEscribir("Ponente_C_Rebolo");}
function fDibujarAbstractRohrer (){echo sEscribir("Ponente_A_Rohrer");}
function fDibujarCurriculumRohrer (){echo sEscribir("Ponente_C_Rohrer");}
function fDibujarAbstractRon (){echo sEscribir("Ponente_A_Ron");}
function fDibujarCurriculumRon (){echo sEscribir("Ponente_C_Ron");}
function fDibujarAbstractStachel (){echo sEscribir("Ponente_A_Stachel");}
function fDibujarCurriculumStachel (){echo sEscribir("Ponente_C_Stachel");}
function fDibujarAbstractCohen (){echo sEscribir("Ponente_A_Cohen");}
function fDibujarCurriculumCohen (){echo sEscribir("Ponente_C_Cohen");}
function fDibujarAbstractYndurain (){echo sEscribir("Ponente_A_Yndurain");}
function fDibujarCurriculumYndurain (){echo sEscribir("Ponente_C_Yndurain");}
function fDibujarAbstractZeilinger (){echo sEscribir("Ponente_A_Zeilinger");}
function fDibujarCurriculumZeilinger (){echo sEscribir("Ponente_C_Zeilinger");}
function fDibujarAbstractPascual (){echo sEscribir("Ponente_A_Pascual");}
function fDibujarCurriculumPascual (){echo sEscribir("Ponente_C_Pascual");}
function fDibujarAbstractLucas (){echo sEscribir("Ponente_A_Lucas");}
function fDibujarCurriculumLucas (){echo sEscribir("Ponente_C_Lucas");}
function fDibujarAbstractFlores (){echo sEscribir("Ponente_A_Flores");}
function fDibujarCurriculumFlores (){echo sEscribir("Ponente_C_Flores");}
function fDibujarComiteOrganizador (){echo sEscribir("Menu_ComiteOrganizador");}
function fDibujarIntroPrograma (){echo sEscribir("Programa_Introduccion");}
function fDibujarPaisVasco(){echo sEscribir("Info_PaisVasco");}
function fDibujarLaCiudad(){echo sEscribir("Info_LaCiudad");}
function fDibujarContacto (){echo sEscribir("Menu_Contacto");}
function fDibujarComoInscribirse (){echo sEscribir("Registro_Como");}
function fDibujarBecas (){echo sEscribir("Registro_Becas");}
function fDibujarAlojamientos (){echo sEscribir("Registro_Alojamiento");}
